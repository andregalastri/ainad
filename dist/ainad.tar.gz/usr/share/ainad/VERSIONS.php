<?php

return [
    "ainad" => "0.3.0-alpha",
    "flat-remix" => "2022-05-25",
    "fluent-cursor" => "2022-09-20",
    "nerd-fonts" => "2.2.2",
];
