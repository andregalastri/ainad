#!/bin/bash

# ------
# This script merge both autostart scripts to load them once, on the startup.
# ------

source "$ainadBaseDir/openbox/autostart-ainad.sh";
source "$ainadBaseDir/openbox/autostart-user.sh";
