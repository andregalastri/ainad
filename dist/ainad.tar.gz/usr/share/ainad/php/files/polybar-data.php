<?php

return array (
  'bg' => '423606',
  'main' => '423610',
  'status' => true,
);
