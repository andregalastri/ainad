<?php

return array (
  'bg' => '82254',
  'main' => '82257',
  'visible' => true,
);
