<?php

return array (
  'bg' => '196218',
  'main' => '196230',
  'status' => true,
);
