<?php

return array (
  'google-chrome' => 
  array (
    0 => '',
    1 => '%{T9}',
  ),
  'code.Code' => 
  array (
    0 => '',
  ),
  'telegram' => 
  array (
    0 => '',
  ),
  'terminal' => 
  array (
    0 => '',
  ),
  'VirtualBox' => 
  array (
    0 => '',
  ),
  'nemo.Nemo' => 
  array (
    0 => '',
  ),
  'inkscape' => 
  array (
    0 => '',
  ),
  'viewnior' => 
  array (
    0 => '',
  ),
  'fontforge' => 
  array (
    0 => '',
  ),
  'filezilla.FileZilla' => 
  array (
    0 => '',
  ),
  'simplescreenrecorder' => 
  array (
    0 => '',
  ),
  'properties' => 
  array (
    0 => '',
  ),
  'mousepad' => 
  array (
    0 => '',
  ),
  'authentication' => 
  array (
    0 => '',
  ),
  'engrampa' => 
  array (
    0 => '',
  ),
  'N/A' => 
  array (
    0 => '',
    1 => '%{T7}',
  ),
  'thunderbird' => 
  array (
    0 => '',
  ),
  'file_progress.Nemo' => 
  array (
    0 => '',
  ),
  'firefox' => 
  array (
    0 => '',
    1 => '%{T9}',
  ),
);
