<?php

return array (
  'google-chrome' => 
  array (
    0 => '',
    1 => 9,
  ),
  'code.Code' => 
  array (
    0 => '',
  ),
  'nemo.Nemo' => 
  array (
    0 => '',
  ),
  'terminal' => 
  array (
    0 => '',
  ),
  'FreeFileSync' => 
  array (
    0 => '',
  ),
  'mousepad' => 
  array (
    0 => '',
  ),
  'telegram' => 
  array (
    0 => '',
  ),
  'thunderbird' => 
  array (
    0 => '',
  ),
  'N/A' => 
  array (
    0 => '',
    1 => 8,
  ),
  'qalculate' => 
  array (
    0 => '',
  ),
  'engrampa' => 
  array (
    0 => '',
  ),
  'flameshot.flameshot' => 
  array (
    0 => '',
  ),
  'VirtualBox' => 
  array (
    0 => '',
  ),
  'gimp' => 
  array (
    0 => '',
  ),
  'authentication' => 
  array (
    0 => '',
  ),
);
