<?php

return array (
  'locale' => 'pt_BR.utf8',
  'language' => 'pt_BR',
  'ainadLanguage' => 'pt_BR',
  'timezone' => 'America/Sao_Paulo',
);
