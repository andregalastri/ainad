<?php

return array (
  'hasUpdates' => false,
  'list' => 
  array (
  ),
  'currentPage' => 1,
);
