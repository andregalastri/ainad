<?php

return array (
  'list' => 
  array (
    0 => 
    array (
      'name' => 'google-chrome',
      'oldVersion' => '107.0.5304.87-1',
      'newVersion' => '107.0.5304.110-1',
      'selected' => true,
    ),
    1 => 
    array (
      'name' => 'gd',
      'oldVersion' => '2.3.3-4',
      'newVersion' => '2.3.3-5',
      'selected' => true,
    ),
    2 => 
    array (
      'name' => 'libavif',
      'oldVersion' => '0.10.1-2',
      'newVersion' => '0.11.1-1',
      'selected' => true,
    ),
    3 => 
    array (
      'name' => 'qt5-base',
      'oldVersion' => '5.15.7+kde+r170-1',
      'newVersion' => '5.15.7+kde+r173-1',
      'selected' => true,
    ),
    4 => 
    array (
      'name' => 'shadow',
      'oldVersion' => '4.11.1-4',
      'newVersion' => '4.12.3-1',
      'selected' => true,
    ),
  ),
  'currentPage' => 1,
);
