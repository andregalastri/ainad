<?php

namespace Core\Interfaces;

/**
 * This interface has only common constants to be used by various classes.
 */
interface CommonDirectories
{
    const ASSETS_DIR = AINAD_BASE_DIR.'/rofi/assets';
}
