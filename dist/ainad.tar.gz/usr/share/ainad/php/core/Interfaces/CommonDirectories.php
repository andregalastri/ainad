<?php

namespace Core\Interfaces;

/**
 * Contains the methods and properties related to the Polybar Taskbar module.
 */
interface CommonDirectories
{
    const ASSETS_DIR = AINAD_BASE_DIR.'/rofi/assets';
}
