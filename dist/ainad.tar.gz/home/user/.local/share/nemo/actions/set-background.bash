#!/bin/bash

ainad-utilities 'Workspace' 'setBackground' "$1"
